# Scout

[![tex-Scout-Icon.png](https://i.postimg.cc/15LG0gn5/tex-Scout-Icon.png)]()

# Overview

[![Screenshot-2024-06-30-160824.png](https://i.postimg.cc/G2NqVbhc/Screenshot-2024-06-30-160824.png)]()

## Passive

[![Screenshot-2024-06-30-155412.png](https://i.postimg.cc/GmwD8ZV4/Screenshot-2024-06-30-155412.png)]()

## Primary

[![Screenshot-2024-06-30-155611.png](https://i.postimg.cc/y8yTV1x1/Screenshot-2024-06-30-155611.png)]()

## Alt Primary

[![Screenshot-2024-06-30-155717.png](https://i.postimg.cc/65dPvNqS/Screenshot-2024-06-30-155717.png)]()

## Secondary

[![Screenshot-2024-06-30-155627.png](https://i.postimg.cc/43KnWPrD/Screenshot-2024-06-30-155627.png)]()

## Utility

[![Screenshot-2024-06-30-155638.png](https://i.postimg.cc/hGRNYPwK/Screenshot-2024-06-30-155638.png)]()

## Special

[![Screenshot-2024-06-30-160547.png](https://i.postimg.cc/Jhp1bk6s/Screenshot-2024-06-30-160547.png)]()

## Primary Swap

[![Screenshot-2024-06-30-155649.png](https://i.postimg.cc/FHyT7bWQ/Screenshot-2024-06-30-155649.png)]()

## Secondary Swap

[![Screenshot-2024-06-30-155700.png](https://i.postimg.cc/7hJVDSGd/Screenshot-2024-06-30-155700.png)]()

# Keywords

### Atomic Crits: Damage is increased by 125% and all attacks apply Weaken.

# Credits

tsuyoikenko - Code, model, animations.

Original concept and art by vo1dstud1os - discord https://codenamecrisis.carrd.co/ - carrd

[![](https://i.postimg.cc/7LXH6zfD/Abyssal-Wars.png)]()

TheTimeSweeper - Incredible new Henry template.

rob - Creator of the glorious Henry template.

Download other tf2 akin characters: 

https://thunderstore.io/package/EnforcerGang/SniperClassic/

https://thunderstore.io/package/EnforcerGang/Rocket/

https://thunderstore.io/package/EnforcerGang/Enforcer/ (Nemforcer)

https://thunderstore.io/package/PopcornFactory/Arsonist_Mod/ 

Contact me on Discord: https://discord.gg/3NaMEsvYeD