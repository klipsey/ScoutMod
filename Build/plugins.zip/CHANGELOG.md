# 0.8.7

- Size of cleaver and baseball increase by 2x

# 0.8.6

- oops

# 0.8.5

- New run/sprint anims (Makes him a teeny tiny bit smoother)
- New Primary Dastardly Dwarf. Heads will roll..
- Added Ancient Scepter support for Swap: Atomic Charge can still be gained while Atomic Core drains
- Atomic Core pulses in intervals over its duration to deal more damage

# 0.8.4

- Increased base ms by 1 to feel more scouty
- Removed unlock condition cause bugged

# 0.8.3

- Removed cooldown from swap (it was funny with void items but a little TOO funny)
- Lowered reload speed slightly
- Token fixes

# 0.8.2

- Scout's utility does damage on intervals now
- Token fixes

# 0.8.1

- ScoutMod.dll is now OfficialScoutMod.dll just in case
- The old ScoutModTF2 doesnt work with 90% of mods in general but ig if you have an extremely niche modpack you can play them together now?

# 0.8.0

- Item displays fixed and added
- Undeprecated now ^
- Config to adjust shotgun recoil for motion sickness

# 0.7.8

- Hopefully fixed item display crash

# 0.7.7

- Fixed stubbed shaders emission

# 0.7.6

- Added official emote support (might be broken until the unofficial support is removed)
- Swapped skills show up in loadout now
- Gave him stubbed shaders

# 0.7.5

- I forgor

# 0.7.4

- Fixed bone rotations for skins
- Added log

# 0.7.3

- Staged reloads

# 0.7.2

- Hopefully fixed sound bug?
- Added grace period when at max gauge
- Added sfx and vfx when hitting max gauge
- Lower cd for weapon swap for qol 
- Config to gain charge while Atomic Charge drains

# 0.7.1 

- Atomic Crits was permanent on projectiles oops

# 0.7.0

- Reload is now tied to attackspeed
- Buffed reload time from 2.5 sec -> 2.0 sec
- Atomic Blast now has 0 cooldown
- Atomic Blast duration scales with stock
- Atomic Core buildup rate increases with Atomic Blasts cooldown reduction
- Mini Crits name changed to Atomic Crits
- Atomic Crits nerfed to deal 125% damage
- Atomic Crits buffed to apply weaken
- Updated Tokens

# 0.6.2

- Cleaver model added
- Added footsteps
- Fixed sfx loop (hopefully)
- Token fixes and quick buff icon fix
- Fixed scout not going invisible for certain items/equipment

# 0.6.1

- Jump polish and some other vfx stuff
- Icon
- Unlock achievement Batter Up: Beat the stage 1 teleporter in under 2 minutes without picking up a single item (Config to force unlock)

# 0.6.0

- Made Ball and Cleaver more accurate
- Cleaver Icon added
- Multiplayer compatible
- Ball now "stuns" any enemy for Cleaver to always work!
- Reworked vfx for Ball and Cleaver
- Cleaned up bat animations
- Glowing bat!?
- Added animations for weapon swapping and cleaned up resting idle animation
- Added new vfx for Atomic Blast


# 0.5.1

- Forgot git url

# 0.5.0

- Scout released!