# 0.7.3

- Staged reloads

# 0.7.2

- Hopefully fixed sound bug?
- Added grace period when at max gauge
- Added sfx and vfx when hitting max gauge
- Lower cd for weapon swap for qol 
- Config to gain charge while Atomic Charge drains

# 0.7.1 

- Atomic Crits was permanent on projectiles oops

# 0.7.0

- Reload is now tied to attackspeed
- Buffed reload time from 2.5 sec -> 2.0 sec
- Atomic Blast now has 0 cooldown
- Atomic Blast duration scales with stock
- Atomic Core buildup rate increases with Atomic Blasts cooldown reduction
- Mini Crits name changed to Atomic Crits
- Atomic Crits nerfed to deal 125% damage
- Atomic Crits buffed to apply weaken
- Updated Tokens

# 0.6.2

- Cleaver model added
- Added footsteps
- Fixed sfx loop (hopefully)
- Token fixes and quick buff icon fix
- Fixed scout not going invisible for certain items/equipment

# 0.6.1

- Jump polish and some other vfx stuff
- Icon
- Unlock achievement Batter Up: Beat the stage 1 teleporter in under 2 minutes without picking up a single item (Config to force unlock)

# 0.6.0

- Made Ball and Cleaver more accurate
- Cleaver Icon added
- Multiplayer compatible
- Ball now "stuns" any enemy for Cleaver to always work!
- Reworked vfx for Ball and Cleaver
- Cleaned up bat animations
- Glowing bat!?
- Added animations for weapon swapping and cleaned up resting idle animation
- Added new vfx for Atomic Blast


# 0.5.1

- Forgot git url

# 0.5.0

- Scout released!