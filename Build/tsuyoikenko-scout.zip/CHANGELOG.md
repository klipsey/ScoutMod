# 0.5.1

- Forgot git url

# 0.5.0

- Scout released!