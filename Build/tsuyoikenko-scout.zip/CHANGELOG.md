# 0.6.0

- Made Ball and Cleaver more accurate
- Cleaver Icon added
- Multiplayer compatible
- Ball now "stuns" any enemy for Cleaver to always work!
- Reworked vfx for Ball and Cleaver
- Cleaned up bat animations
- Glowing bat!?
- Added animations for weapon swapping and cleaned up resting idle animation
- Added new vfx for Atomic Blast


# 0.5.1

- Forgot git url

# 0.5.0

- Scout released!