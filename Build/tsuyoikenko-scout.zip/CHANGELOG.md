# 0.5.0

- Scout released!